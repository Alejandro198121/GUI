package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import view.VentanaPrincipal;

public class Controller implements ActionListener {

	private VentanaPrincipal vista;

	public Controller() {
		vista = new VentanaPrincipal();
		asignarOyentes();
	}

	public void asignarOyentes() {
		// addActionListener(this) es el sensor
		vista.getPanel1().getOpcionesGenero().addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		if (comando.equals("FUNCIONA")) {
			JOptionPane.showMessageDialog(vista, e);
		}
	}
}
