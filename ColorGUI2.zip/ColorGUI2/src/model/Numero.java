package model;

public class Numero {

	private int n;

	public Numero(int n) {
		this.n = n;
	}

	public int multiplosNumero(int numeroBase, int multiploAnterior) {
		int multiploNew = multiploAnterior + numeroBase;
		return multiploNew;
	}
	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

}
