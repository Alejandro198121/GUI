package view;

import javax.swing.JPanel;

public class PanelAbajo extends JPanel {



	public void inicializarComponentes() {
	}
}