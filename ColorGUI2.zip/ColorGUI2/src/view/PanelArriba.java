package view;

import java.awt.Color;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelArriba extends JPanel {

	private JLabel etiquetaNombre;
	private JLabel etiquetaGenero;
	private JTextField campoNombre;
	private JComboBox opcionesGenero;
	
	public PanelArriba() {
		setLayout(null);
		inicializarComponentes();
		setBackground(Color.cyan);
		setVisible(true);
	}
	
	public void inicializarComponentes() {
	etiquetaNombre = new JLabel("ingrese su nombre: ");
	etiquetaNombre.setBounds(100, 50, 670, 30);
	add (etiquetaNombre);
	
	etiquetaGenero = new JLabel("seleccione su genero: ");
	etiquetaGenero.setBounds(100, 100, 100, 100);
	add (etiquetaGenero);
	
	campoNombre = new JTextField();
	campoNombre.setBounds(100, 100, 100, 100);
	campoNombre.setHorizontalAlignment(JTextField.CENTER);
	add (campoNombre);
	
	String[] lista = {"Masculino", "Femenino", "prefiero no decirlo"};
	opcionesGenero = new JComboBox(lista);
	opcionesGenero.setBounds(100, 100, 100, 100);
	opcionesGenero.setActionCommand("FUNCIONA");
	add (opcionesGenero);
	
	}

	public JLabel getEtiquetaNombre() {
		return etiquetaNombre;
	}

	public void setEtiquetaNombre(JLabel etiquetaNombre) {
		this.etiquetaNombre = etiquetaNombre;
	}

	public JLabel getEtiquetaGenero() {
		return etiquetaGenero;
	}

	public void setEtiquetaGenero(JLabel etiquetaGenero) {
		this.etiquetaGenero = etiquetaGenero;
	}

	public JTextField getCampoNombre() {
		return campoNombre;
	}

	public void setCampoNombre(JTextField campoNombre) {
		this.campoNombre = campoNombre;
	}

	public JComboBox getOpcionesGenero() {
		return opcionesGenero;
	}

	public void setOpcionesGenero(JComboBox opcionesGenero) {
		this.opcionesGenero = opcionesGenero;
	}
	
}