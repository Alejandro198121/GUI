package view;

import java.awt.Color;

import javax.swing.JFrame;

public class VentanaPrincipal extends JFrame{
	
	private PanelArriba panel1;
	//private PanelAbajo panel2;
	
	public VentanaPrincipal() {
		setTitle("DOS VENTANAS");
		setSize(700, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.darkGray);
		getContentPane().setLayout(null);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
		
		inicializarPaneles();
	}
	
	public void inicializarPaneles() {
		panel1 = new PanelArriba();
		panel1.setBounds(25, 25, 635, 310);
		getContentPane().add(panel1);
	}

	public PanelArriba getPanel1() {
		return panel1;
	}

	public void setPanel1(PanelArriba panel1) {
		this.panel1 = panel1;
	}
	
	
}